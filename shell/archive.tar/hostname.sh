#!/bin/sh
hostname
